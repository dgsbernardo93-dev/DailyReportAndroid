var exec = require('cordova/exec');

module.exports = {
    // texto: string | fotos: array de dataURL/base64 | pacotes: ex. ['com.whatsapp', 'com.whatsapp.w4b']
    share: function (texto, fotos, pacotes, sucesso, erro) {
        exec(sucesso, erro, 'DailyShare', 'share', [texto || '', fotos || [], pacotes || []]);
    }
};
