package com.usinagem.dailyshare;

import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;

import androidx.core.content.FileProvider;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

/**
 * Compartilha texto + fotos com o WhatsApp (ou outro app escolhido).
 * args: [texto, [fotos em base64/dataURL], [pacotes preferidos]]
 */
public class DailyShare extends CordovaPlugin {

    @Override
    public boolean execute(String action, final JSONArray args, final CallbackContext callback) throws JSONException {
        if (!"share".equals(action)) {
            return false;
        }
        cordova.getThreadPool().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    final Intent intent = montarIntent(args);
                    final JSONArray pacotes = args.optJSONArray(2);
                    cordova.getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            abrir(intent, pacotes, callback);
                        }
                    });
                } catch (Exception e) {
                    callback.error("Erro ao preparar fotos: " + e.getMessage());
                }
            }
        });
        return true;
    }

    private Intent montarIntent(JSONArray args) throws Exception {
        String texto = args.optString(0, "");
        JSONArray fotos = args.optJSONArray(1);
        Context ctx = cordova.getActivity();

        File pasta = new File(ctx.getCacheDir(), "dailyreport");
        if (!pasta.exists()) {
            pasta.mkdirs();
        }
        File[] antigos = pasta.listFiles();
        if (antigos != null) {
            for (File f : antigos) {
                f.delete();
            }
        }

        String autoridade = ctx.getPackageName() + ".cdv.core.file.provider";
        long agora = System.currentTimeMillis();
        ArrayList<Uri> uris = new ArrayList<Uri>();
        if (fotos != null) {
            for (int i = 0; i < fotos.length(); i++) {
                String b64 = fotos.getString(i);
                int virgula = b64.indexOf(',');
                if (virgula >= 0) {
                    b64 = b64.substring(virgula + 1);
                }
                byte[] dados = Base64.decode(b64, Base64.DEFAULT);
                File arquivo = new File(pasta, "daily_report_" + agora + "_" + (i + 1) + ".jpg");
                FileOutputStream out = new FileOutputStream(arquivo);
                try {
                    out.write(dados);
                } finally {
                    out.close();
                }
                uris.add(FileProvider.getUriForFile(ctx, autoridade, arquivo));
            }
        }

        Intent intent;
        if (uris.size() > 1) {
            intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        } else {
            intent = new Intent(Intent.ACTION_SEND);
            if (uris.size() == 1) {
                intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
            }
        }
        intent.setType(uris.isEmpty() ? "text/plain" : "image/jpeg");
        intent.putExtra(Intent.EXTRA_TEXT, texto);
        if (!uris.isEmpty()) {
            ClipData clip = ClipData.newRawUri("", uris.get(0));
            for (int i = 1; i < uris.size(); i++) {
                clip.addItem(new ClipData.Item(uris.get(i)));
            }
            intent.setClipData(clip);
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return intent;
    }

    private void abrir(Intent intent, JSONArray pacotes, CallbackContext callback) {
        if (pacotes != null) {
            for (int i = 0; i < pacotes.length(); i++) {
                String pacote = pacotes.optString(i, "");
                if (pacote.length() == 0) {
                    continue;
                }
                try {
                    Intent alvo = new Intent(intent);
                    alvo.setPackage(pacote);
                    cordova.getActivity().startActivity(alvo);
                    callback.success(pacote);
                    return;
                } catch (ActivityNotFoundException e) {
                    // app não instalado: tenta o próximo
                }
            }
        }
        try {
            cordova.getActivity().startActivity(Intent.createChooser(intent, "Enviar Daily Report"));
            callback.success("chooser");
        } catch (Exception e) {
            callback.error("Nenhum app para compartilhar: " + e.getMessage());
        }
    }
}
