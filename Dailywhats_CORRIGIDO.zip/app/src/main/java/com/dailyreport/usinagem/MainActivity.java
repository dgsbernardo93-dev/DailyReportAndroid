package com.dailyreport.usinagem;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ClipData;
import android.util.Base64;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
import androidx.core.content.FileProvider;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private Uri cameraPhotoUri;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidShare(), "AndroidShare");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent;
                    if (params.isCaptureEnabled()) {
                        File dir = new File(getCacheDir(), "report_photos");
                        if (!dir.exists()) dir.mkdirs();
                        File photo = File.createTempFile("camera_", ".jpg", dir);
                        cameraPhotoUri = FileProvider.getUriForFile(
                            MainActivity.this, getPackageName() + ".fileprovider", photo);
                        intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraPhotoUri);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        intent.setClipData(ClipData.newRawUri("foto", cameraPhotoUri));
                        if (intent.resolveActivity(getPackageManager()) == null) {
                            cameraPhotoUri = null;
                            intent = galleryIntent();
                        }
                    } else {
                        intent = galleryIntent();
                    }
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    Uri[] fallback = null;
                    try {
                        Intent fallbackIntent = params.createIntent();
                        startActivityForResult(fallbackIntent, FILE_CHOOSER_REQUEST);
                        return true;
                    } catch (Exception ignored) {
                        filePathCallback = null;
                        callback.onReceiveValue(fallback);
                        return false;
                    }
                }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private Intent galleryIntent() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        return intent;
    }

    private class AndroidShare {
        @JavascriptInterface public void enviarParaWhatsApp(String texto, String fotosJson) {
            runOnUiThread(() -> {
                try {
                    JSONArray fotos = new JSONArray(fotosJson);
                    ArrayList<Uri> uris = new ArrayList<>();
                    File dir = new File(getCacheDir(), "report_photos");
                    if (!dir.exists()) dir.mkdirs();
                    for (int i = 0; i < fotos.length(); i++) {
                        JSONObject item = fotos.getJSONObject(i);
                        String name = item.optString("name", "foto" + i + ".jpg").replaceAll("[^a-zA-Z0-9._-]", "_");
                        byte[] bytes = Base64.decode(item.getString("data"), Base64.DEFAULT);
                        File file = new File(dir, System.currentTimeMillis() + "_" + i + "_" + name);
                        try (FileOutputStream fos = new FileOutputStream(file)) { fos.write(bytes); }
                        uris.add(FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file));
                    }

                    Intent intent;
                    if (uris.isEmpty()) {
                        intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("text/plain");
                    } else if (uris.size() == 1) {
                        intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("image/*");
                        intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                    } else {
                        intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                        intent.setType("image/*");
                        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                    }
                    intent.putExtra(Intent.EXTRA_TEXT, texto);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.setPackage("com.whatsapp");
                    try {
                        startActivity(intent);
                    } catch (android.content.ActivityNotFoundException notInstalled) {
                        intent.setPackage(null);
                        startActivity(Intent.createChooser(intent, "Enviar Daily Report"));
                    }
                } catch (Exception e) {
                    android.widget.Toast.makeText(MainActivity.this, "Falha ao enviar. Verifique se o WhatsApp está instalado e tente novamente.", android.widget.Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK) {
                if (cameraPhotoUri != null) {
                    // A URI de saída da câmera aponta para o arquivo em tamanho original.
                    results = new Uri[] { cameraPhotoUri };
                } else if (data != null) {
                    if (data.getClipData() != null) {
                        ClipData clip = data.getClipData();
                        results = new Uri[clip.getItemCount()];
                        for (int i = 0; i < clip.getItemCount(); i++) results[i] = clip.getItemAt(i).getUri();
                    } else if (data.getData() != null) {
                        results = new Uri[] { data.getData() };
                    }
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            cameraPhotoUri = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
