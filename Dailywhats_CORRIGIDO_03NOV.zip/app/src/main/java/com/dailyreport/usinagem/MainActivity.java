package com.dailyreport.usinagem;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ClipData;
import android.util.Base64;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
import androidx.core.content.FileProvider;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int SHARE_REQUEST = 1002;
    private Uri cameraOutputUri;
    private boolean resetAfterShare = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidShare(), "AndroidShare");
        webView.setWebViewClient(new WebViewClient() {
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    if (params != null && params.isCaptureEnabled()) {
                        abrirCamera();
                    } else {
                        abrirGaleria();
                    }
                } catch (Exception e) {
                    concluirSeletor(null);
                    android.widget.Toast.makeText(MainActivity.this,
                        "Não foi possível abrir a câmera ou galeria.", android.widget.Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void abrirGaleria() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(Intent.createChooser(intent, "Escolher imagens"), FILE_CHOOSER_REQUEST);
    }

    private void abrirCamera() throws Exception {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            concluirSeletor(null);
            android.widget.Toast.makeText(this, "Nenhum aplicativo de câmera disponível.",
                android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        File dir = new File(getCacheDir(), "report_photos");
        if (!dir.exists()) dir.mkdirs();
        File photo = new File(dir, "camera_" + System.currentTimeMillis() + ".jpg");
        cameraOutputUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
        intent.setClipData(ClipData.newUri(getContentResolver(), "Foto do relatório", cameraOutputUri));
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        startActivityForResult(intent, FILE_CHOOSER_REQUEST);
    }

    private void concluirSeletor(Uri[] uris) {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(uris);
            filePathCallback = null;
        }
        cameraOutputUri = null;
    }

    private class AndroidShare {
        @JavascriptInterface public void enviarParaWhatsApp(String texto, String fotosJson) {
            runOnUiThread(() -> {
                try {
                    JSONArray fotos = new JSONArray(fotosJson);
                    ArrayList<Uri> uris = new ArrayList<>();
                    File dir = new File(getCacheDir(), "report_photos");
                    if (!dir.exists()) dir.mkdirs();
                    for (int i = 0; i < fotos.length(); i++) {
                        JSONObject item = fotos.getJSONObject(i);
                        String name = item.optString("name", "foto" + i + ".jpg").replaceAll("[^a-zA-Z0-9._-]", "_");
                        String mime = item.optString("type", "image/jpeg");
                        byte[] bytes = Base64.decode(item.getString("data"), Base64.DEFAULT);
                        File file = new File(dir, System.currentTimeMillis() + "_" + name);
                        try (FileOutputStream fos = new FileOutputStream(file)) { fos.write(bytes); }
                        uris.add(FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file));
                    }

                    Intent intent;
                    if (uris.isEmpty()) {
                        intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("text/plain");
                    } else if (uris.size() == 1) {
                        intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("image/*");
                        intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                    } else {
                        intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                        intent.setType("image/*");
                        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                    }
                    intent.putExtra(Intent.EXTRA_TEXT, texto);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    // Abre o aplicativo WhatsApp diretamente, sem navegar para uma página web.
                    intent.setPackage("com.whatsapp");
                    try {
                        resetAfterShare = true;\n                        startActivityForResult(intent, SHARE_REQUEST);
                    } catch (android.content.ActivityNotFoundException notInstalled) {
                        intent.setPackage(null);
                        resetAfterShare = true;\n                        startActivityForResult(Intent.createChooser(intent, "Enviar Daily Report"), SHARE_REQUEST);
                    }
                } catch (Exception e) {
                    android.widget.Toast.makeText(MainActivity.this, "Falha ao enviar. Verifique se o WhatsApp está instalado e tente novamente.", android.widget.Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SHARE_REQUEST) {
            // A limpeza é executada em onResume, quando o usuário retorna do WhatsApp.
            return;
        }
        if (requestCode != FILE_CHOOSER_REQUEST) return;
        if (resultCode != RESULT_OK) {
            concluirSeletor(null);
            return;
        }
        if (cameraOutputUri != null) {
            concluirSeletor(new Uri[]{cameraOutputUri});
            return;
        }
        ArrayList<Uri> selecionadas = new ArrayList<>();
        if (data != null && data.getClipData() != null) {
            ClipData clip = data.getClipData();
            for (int i = 0; i < clip.getItemCount(); i++) {
                Uri uri = clip.getItemAt(i).getUri();
                if (uri != null) selecionadas.add(uri);
            }
        } else if (data != null && data.getData() != null) {
            selecionadas.add(data.getData());
        }
        concluirSeletor(selecionadas.isEmpty() ? null : selecionadas.toArray(new Uri[0]));
    }

    @Override protected void onResume() {
        super.onResume();
        if (resetAfterShare && webView != null) {
            resetAfterShare = false;
            webView.postDelayed(() -> webView.evaluateJavascript(
                "if (typeof limparFormulario === 'function') limparFormulario();", null), 350);
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
