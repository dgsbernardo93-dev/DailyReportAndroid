package com.dailyreport.usinagem;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ClipData;
import android.os.Environment;
import android.widget.Toast;
import java.io.File;
import java.util.ArrayList;
import androidx.core.content.FileProvider;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private String fileChooserMode = "gallery";
    private Uri cameraOutputUri;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidShare(), "AndroidShare");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    if ("camera".equals(fileChooserMode)) {
                        abrirCamera();
                    } else {
                        abrirGaleria();
                    }
                } catch (Exception e) {
                    filePathCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "Não foi possível abrir as imagens.", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void abrirCamera() {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File dir = new File(getCacheDir(), "report_photos");
        if (!dir.exists()) dir.mkdirs();
        File photo = new File(dir, "camera_" + System.currentTimeMillis() + ".jpg");
        cameraOutputUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
        camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
        camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            startActivityForResult(camera, FILE_CHOOSER_REQUEST);
        } catch (Exception e) {
            entregarResultado(null);
            Toast.makeText(this, "Não foi possível iniciar a câmera.", Toast.LENGTH_LONG).show();
        }
    }

    private void abrirGaleria() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(Intent.createChooser(pick, "Escolher fotos"), FILE_CHOOSER_REQUEST);
    }

    private void entregarResultado(Uri[] uris) {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(uris);
            filePathCallback = null;
        }
        cameraOutputUri = null;
        fileChooserMode = "gallery";
    }

    private class AndroidShare {
        @JavascriptInterface public void setFileChooserMode(String mode) {
            fileChooserMode = "camera".equals(mode) ? "camera" : "gallery";
        }

        @JavascriptInterface public void enviarParaWhatsApp(String texto, String fotosJson) {
            runOnUiThread(() -> {
                try {
                    org.json.JSONArray fotos = new org.json.JSONArray(fotosJson);
                    ArrayList<Uri> uris = new ArrayList<>();
                    File dir = new File(getCacheDir(), "report_photos");
                    if (!dir.exists()) dir.mkdirs();
                    for (int i = 0; i < fotos.length(); i++) {
                        org.json.JSONObject item = fotos.getJSONObject(i);
                        String name = item.optString("name", "foto" + i + ".jpg").replaceAll("[^a-zA-Z0-9._-]", "_");
                        byte[] bytes = android.util.Base64.decode(item.getString("data"), android.util.Base64.DEFAULT);
                        File file = new File(dir, System.currentTimeMillis() + "_" + name);
                        try (java.io.FileOutputStream fos = new java.io.FileOutputStream(file)) { fos.write(bytes); }
                        uris.add(FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file));
                    }
                    Intent intent;
                    if (uris.isEmpty()) {
                        intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("text/plain");
                    } else if (uris.size() == 1) {
                        intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("image/*");
                        intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                    } else {
                        intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                        intent.setType("image/*");
                        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                    }
                    intent.putExtra(Intent.EXTRA_TEXT, texto);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.setPackage("com.whatsapp");
                    try { startActivity(intent); }
                    catch (android.content.ActivityNotFoundException e) {
                        intent.setPackage(null);
                        startActivity(Intent.createChooser(intent, "Enviar Daily Report"));
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Falha ao enviar. Verifique se o WhatsApp está instalado.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST) return;
        if (resultCode != RESULT_OK) {
            entregarResultado(null);
            return;
        }
        if ("camera".equals(fileChooserMode)) {
            Uri result = cameraOutputUri;
            if (result != null) entregarResultado(new Uri[]{result});
            else entregarResultado(null);
            return;
        }
        ArrayList<Uri> results = new ArrayList<>();
        if (data != null) {
            ClipData clip = data.getClipData();
            if (clip != null) {
                for (int i = 0; i < clip.getItemCount(); i++) {
                    Uri uri = clip.getItemAt(i).getUri();
                    if (uri != null) results.add(uri);
                }
            } else if (data.getData() != null) {
                results.add(data.getData());
            }
        }
        entregarResultado(results.isEmpty() ? null : results.toArray(new Uri[0]));
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
